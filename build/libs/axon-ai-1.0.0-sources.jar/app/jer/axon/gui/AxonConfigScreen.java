package app.jer.axon.gui;

import app.jer.axon.Axon;
import app.jer.axon.service.LLMService;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AxonConfigScreen extends class_437 {
    private class_342 apiKeyBox;
    private class_342 providerBox;
    private class_342 modelBox;

    public AxonConfigScreen() {
        super(class_2561.method_43470("Axon AI Configuration"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        int centerX = this.field_22789 / 2;
        int fieldWidth = 200;
        int fieldX = centerX - fieldWidth / 2;
        int buttonY = 60;

        this.apiKeyBox = new class_342(this.field_22793, fieldX, buttonY, fieldWidth, 20, class_2561.method_43470("API Key"));
        this.apiKeyBox.method_1852("");
        method_37063(this.apiKeyBox);

        this.providerBox = new class_342(this.field_22793, fieldX, buttonY + 30, fieldWidth, 20, class_2561.method_43470("Provider (google/openrouter/etc)"));
        this.providerBox.method_1852(LLMService.getProvider());
        method_37063(this.providerBox);

        this.modelBox = new class_342(this.field_22793, fieldX, buttonY + 60, fieldWidth, 20, class_2561.method_43470("Model"));
        this.modelBox.method_1852(LLMService.getModel());
        method_37063(this.modelBox);

        method_37063(class_4185.method_46430(class_2561.method_43470("Save"), button -> save())
                .method_46434(fieldX, buttonY + 100, 100, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), button -> method_25419())
                .method_46434(fieldX + 110, buttonY + 100, 100, 20).method_46431());
    }

    private void save() {
        String key = this.apiKeyBox.method_1882().trim();
        String provider = this.providerBox.method_1882().trim();
        String model = this.modelBox.method_1882().trim();

        if (provider.isEmpty()) {
            provider = "google";
        }

        try {
            LLMService.setKey(key);
            LLMService.setProvider(provider);
            if (!model.isEmpty()) {
                LLMService.setModel(model);
            }

            Axon.chatMessage(class_2561.method_43470("Axon AI settings saved.").method_27692(class_124.field_1060));
            method_25419();
        } catch (Exception e) {
            Axon.chatMessage(class_2561.method_43470("Failed to save: " + e.getMessage()).method_27692(class_124.field_1061));
        }
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(null);
        super.method_25419();
    }
}
