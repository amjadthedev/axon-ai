package app.jer.axon;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class Utils {
    public static class_5250 prefixText(String prefix) {
        return class_2561.method_43473().method_10852(class_2561.method_43470("[Axon AI] ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470(prefix + ": ").method_27692(class_124.field_1075));
    }
}
