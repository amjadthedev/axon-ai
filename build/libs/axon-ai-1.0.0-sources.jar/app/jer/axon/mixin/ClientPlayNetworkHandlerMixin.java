package app.jer.axon.mixin;

import app.jer.axon.Axon;
import app.jer.axon.Utils;
import app.jer.axon.agent.AxonAgent;
import app.jer.axon.gui.AxonConfigScreen;
import app.jer.axon.service.LLMService;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "sendChatCommand(Ljava/lang/String;)V", at = @At("HEAD"), cancellable = true)
    private void onSendChatCommand(String command, CallbackInfo ci) {
        if (command == null || !command.startsWith("/a")) {
            return;
        }

        String cmd = command.substring(1).trim();

        if (cmd.equals("a")) {
            Axon.chatMessage("Hello World!");
            ci.cancel();
            return;
        }

        if (cmd.startsWith("a ")) {
            String message = cmd.substring(2).trim();
            if (!message.isEmpty()) {
                AxonAgent.userMessage(message);
            }
            ci.cancel();
            return;
        }

        if (cmd.startsWith("a-key ")) {
            String rest = cmd.substring(6).trim();
            String[] parts = rest.split(" ", 2);
            String key = parts[0];
            String provider = parts.length > 1 ? parts[1] : null;

            LLMService.setKey(key);
            if (provider != null && !provider.isEmpty()) {
                try {
                    LLMService.setProvider(provider);
                } catch (IllegalArgumentException e) {
                    class_5250 msg = Utils.prefixText("Axon AI")
                            .method_10852(class_2561.method_43470("Unknown provider '" + provider + "'").method_27692(class_124.field_1061));
                    Axon.chatMessage(msg);
                    ci.cancel();
                    return;
                }
            }

            String activeProvider = LLMService.getProvider();
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Key set successfully").method_27692(class_124.field_1077))
                    .method_10852(class_2561.method_43470(" (provider: " + LLMService.getProviderDisplayName(activeProvider) + ")").method_27692(class_124.field_1080));
            Axon.chatMessage(msg);
            ci.cancel();
            return;
        }

        if (cmd.equals("a-model")) {
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Current model: ").method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(LLMService.getModel()).method_27692(class_124.field_1060));
            Axon.chatMessage(msg);
            class_5250 msg2 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Current provider: ").method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(LLMService.getProviderDisplayName(LLMService.getProvider()) + " (" + LLMService.getProvider() + ")").method_27692(class_124.field_1060));
            Axon.chatMessage(msg2);
            ci.cancel();
            return;
        }

        if (cmd.startsWith("a-model ")) {
            String model = cmd.substring(8).trim();
            if (!model.isEmpty()) {
                LLMService.setModel(model);
                class_5250 msg = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470("Model set to ").method_27692(class_124.field_1077))
                        .method_10852(class_2561.method_43470(LLMService.getModel()).method_27692(class_124.field_1060));
                Axon.chatMessage(msg);
            }
            ci.cancel();
            return;
        }

        if (cmd.equals("a-clear")) {
            AxonAgent.clearChat();
            ci.cancel();
            return;
        }

        if (cmd.equals("a-gui")) {
            class_310 client = class_310.method_1551();
            client.execute(() -> client.method_1507(new AxonConfigScreen()));
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Opened Axon AI configuration screen.").method_27692(class_124.field_1060));
            Axon.chatMessage(msg);
            ci.cancel();
            return;
        }
    }
}
