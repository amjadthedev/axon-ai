package app.jer.axon;

import app.jer.axon.agent.AxonAgent;
import app.jer.axon.command.CommandRegistrar;
import app.jer.axon.service.LLMService;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Axon implements ClientModInitializer {
    public static final String MOD_ID = "axon";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static void chatMessage(class_2561 message) {
        class_310.method_1551().execute(() -> {
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1724 != null) {
                client.field_1724.method_7353(message, false);
            }
        });
    }

    public static void chatMessage(String message) {
        chatMessage(class_2561.method_30163(message));
    }

    public static void statusOverlay(class_2561 message) {
        class_310.method_1551().execute(() -> {
            class_310 client = class_310.method_1551();
            if (client != null && client.field_1724 != null) {
                client.field_1724.method_7353(message, true);
            }
        });
    }

    public static void statusOverlay(String message) {
        statusOverlay(class_2561.method_30163(message));
    }

    @Override
    public void onInitializeClient() {
        CommandRegistrar.register();
        LLMService.initialize();
        AxonAgent.initialize();
        LOGGER.info("Axon AI initialized");
    }
}
