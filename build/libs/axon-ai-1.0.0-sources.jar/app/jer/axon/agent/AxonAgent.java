package app.jer.axon.agent;

import app.jer.axon.Axon;
import app.jer.axon.service.LLMService;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AxonAgent {
    private static final Logger LOGGER = LoggerFactory.getLogger("axon-agent");

    private static volatile boolean initialized = false;

    public static void initialize() {
        initialized = true;
        LOGGER.info("Axon AI agent loop started");
    }

    public static void userMessage(String text) {
        if (!initialized) {
            LOGGER.warn("Axon AI agent not initialized");
            return;
        }
        LOGGER.info("Axon AI user message queued ({} chars)", text.length());

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) {
            Axon.chatMessage(class_2561.method_43470("Axon AI: world not loaded yet."));
            return;
        }

        Axon.chatMessage(class_2561.method_43470("Axon AI: processing your message..."));
    }

    public static void clearChat() {
        LOGGER.info("Axon AI chat cleared");
        Axon.chatMessage(class_2561.method_43470("Axon AI: conversation memory cleared."));
    }
}
