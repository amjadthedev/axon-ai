package app.jer.axon.command;

import app.jer.axon.Axon;
import app.jer.axon.agent.AxonAgent;
import app.jer.axon.service.LLMService;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

public class CommandRegistrar {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((
                dispatcher,
                registryAccess,
                environment
        ) -> {
            dispatcher.register(class_2170.method_9247("a")
                    .then(class_2170.method_9244("message", StringArgumentType.greedyString())
                            .executes(new PromptCommand())
                    )
                    .executes(ctx -> {
                        Axon.chatMessage("Hello World!");
                        return 1;
                    })
            );
            dispatcher.register(class_2170.method_9247("a-clear")
                    .executes(new ClearCommand())
            );
            dispatcher.register(class_2170.method_9247("a-key")
                    .then(class_2170.method_9244("key", StringArgumentType.string())
                            .executes(new KeyCommand())
                            .then(class_2170.method_9244("provider", StringArgumentType.string())
                                    .executes(new KeyCommand())
                            )
                    )
            );
            dispatcher.register(class_2170.method_9247("a-model")
                    .executes(new ModelCommand.ShowCommand())
                    .then(class_2170.method_9244("model", StringArgumentType.greedyString())
                            .executes(new ModelCommand())
                    )
            );
            dispatcher.register(class_2170.method_9247("a-gui")
                    .executes(new GuiCommand())
            );
        });
        Axon.LOGGER.info("Axon AI commands registered");
    }

    public static class ClearCommand implements Command<class_2168> {
        @Override
        public int run(CommandContext<class_2168> commandContext) {
            try {
                AxonAgent.clearChat();
            } catch (Exception e) {
                Axon.LOGGER.error("Error sending clear command to agent", e);
                commandContext.getSource().method_9213(class_2561.method_43470("Error: " + e.getMessage()));
                return 0;
            }
            return 1;
        }
    }
}
