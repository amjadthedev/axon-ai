package app.jer.axon.command;

import app.jer.axon.Axon;
import app.jer.axon.Utils;
import app.jer.axon.agent.AxonAgent;
import app.jer.axon.service.LLMService;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class PromptCommand implements Command<class_2168> {
    @Override
    public int run(CommandContext<class_2168> commandContext) {
        String message = StringArgumentType.getString(commandContext, "message");
        Axon.LOGGER.info("Received /a message ({} chars), queueing for agent", message.length());

        if (LLMService.getApi() == null) {
            Axon.LOGGER.warn("Rejected /a message: no API key configured");
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("No API key set. Use /a-key <key> [provider]").method_27692(class_124.field_1061));
            Axon.chatMessage(msg);
            return 0;
        }

        try {
            AxonAgent.userMessage(message);
        } catch (Exception e) {
            Axon.LOGGER.error("Error sending user prompt to agent", e);
            commandContext.getSource().method_9213(class_2561.method_43470("Error: " + e.getMessage()));
            return 0;
        }

        return 1;
    }
}
