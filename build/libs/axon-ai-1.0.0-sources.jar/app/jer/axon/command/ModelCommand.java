package app.jer.axon.command;

import app.jer.axon.Axon;
import app.jer.axon.Utils;
import app.jer.axon.service.LLMService;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.Locale;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class ModelCommand implements Command<class_2168> {
    @Override
    public int run(CommandContext<class_2168> commandContext) {
        String requestedModel = StringArgumentType.getString(commandContext, "model").trim();
        Axon.LOGGER.info("Received /a-model with raw input: '{}'", requestedModel);
        if (requestedModel.isEmpty()) {
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Usage: /a-model <model-id> or /a-model auto").method_27692(class_124.field_1061));
            Axon.chatMessage(msg);
            return 0;
        }
        if ("auto".equalsIgnoreCase(requestedModel) || "default".equalsIgnoreCase(requestedModel) || "none".equalsIgnoreCase(requestedModel)) {
            String defaultModel = LLMService.resetModelToProviderDefault();
            if (defaultModel != null) {
                Axon.LOGGER.info("Model reset to provider default: {}", defaultModel);
                class_5250 msg = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470("Model reset to provider default: ").method_27692(class_124.field_1077))
                        .method_10852(class_2561.method_43470(defaultModel).method_27692(class_124.field_1060));
                Axon.chatMessage(msg);
            } else {
                class_5250 msg = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470("No default model known for provider '" + LLMService.getProvider() + "'. Provide a model id explicitly.").method_27692(class_124.field_1061));
                Axon.chatMessage(msg);
            }
            return 1;
        }
        LLMService.setModel(requestedModel);
        Axon.LOGGER.info("Model changed to {}", LLMService.getModel());
        class_5250 msg = Utils.prefixText("Axon AI")
                .method_10852(class_2561.method_43470("Model set to ").method_27692(class_124.field_1077))
                .method_10852(class_2561.method_43470(LLMService.getModel()).method_27692(class_124.field_1060));
        Axon.chatMessage(msg);
        return 1;
    }

    public static class ShowCommand implements Command<class_2168> {
        @Override
        public int run(CommandContext<class_2168> commandContext) {
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Current model: ").method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(LLMService.getModel()).method_27692(class_124.field_1060));
            Axon.chatMessage(msg);
            class_5250 msg2 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Current provider: ").method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(LLMService.getProviderDisplayName(LLMService.getProvider()) + " (" + LLMService.getProvider() + ")").method_27692(class_124.field_1060));
            Axon.chatMessage(msg2);
            if (!"google".equals(LLMService.getProvider()) && LLMService.getModel().toLowerCase(Locale.ROOT).startsWith("gemini")) {
                class_5250 msg3 = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470("Warning: model '" + LLMService.getModel() + "' looks like a Google Gemini model, but the provider is not Google. Set a model ID your provider supports, e.g. /a-model <provider-model-id>").method_27692(class_124.field_1061));
                Axon.chatMessage(msg3);
            }
            String defaultModel = LLMService.getDefaultModelFor(LLMService.getProvider());
            if (defaultModel != null && !defaultModel.equals(LLMService.getModel())) {
                class_5250 msg4 = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470("Free default for this provider: " + defaultModel).method_27692(class_124.field_1062));
                Axon.chatMessage(msg4);
            }
            class_5250 msg5 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Suggested models for " + LLMService.getProvider() + ":").method_27692(class_124.field_1080));
            Axon.chatMessage(msg5);
            for (String suggestion : LLMService.getSuggestedModels(LLMService.getProvider())) {
                class_5250 msg6 = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470(" - " + suggestion).method_27692(class_124.field_1062));
                Axon.chatMessage(msg6);
            }
            class_5250 msg7 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Usage: /a-model <model-id> or /a-model auto").method_27692(class_124.field_1080));
            Axon.chatMessage(msg7);
            return 1;
        }
    }
}
