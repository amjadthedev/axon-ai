package app.jer.axon.command;

import app.jer.axon.Axon;
import app.jer.axon.Utils;
import app.jer.axon.gui.AxonConfigScreen;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public class GuiCommand implements Command<class_2168> {
    @Override
    public int run(CommandContext<class_2168> commandContext) {
        Axon.LOGGER.info("Received /a-gui command, opening configuration screen");
        class_310 client = class_310.method_1551();
        client.execute(() -> client.method_1507(new AxonConfigScreen()));
        class_5250 msg = Utils.prefixText("Axon AI")
                .method_10852(class_2561.method_43470("Opened Axon AI configuration screen.").method_27692(class_124.field_1060));
        Axon.chatMessage(msg);
        return 1;
    }
}
