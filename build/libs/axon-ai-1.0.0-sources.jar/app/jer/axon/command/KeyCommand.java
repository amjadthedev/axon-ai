package app.jer.axon.command;

import app.jer.axon.Axon;
import app.jer.axon.Utils;
import app.jer.axon.service.LLMService;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class KeyCommand implements Command<class_2168> {
    @Override
    public int run(CommandContext<class_2168> commandContext) {
        String key = StringArgumentType.getString(commandContext, "key").trim();
        Axon.LOGGER.info("Received /a-key command (key length {}).", key.length());

        String provider = null;
        try {
            provider = StringArgumentType.getString(commandContext, "provider").trim();
        } catch (IllegalArgumentException ignored) {
        }

        if (provider != null && !LLMService.isSupportedProvider(provider)) {
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Unknown provider '" + provider + "'.").method_27692(class_124.field_1061));
            Axon.chatMessage(msg);
            class_5250 msg2 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Providers available: " + LLMService.getProvidersDescription()).method_27692(class_124.field_1080));
            Axon.chatMessage(msg2);
            class_5250 msg3 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Usage: /a-key <api key> [provider]").method_27692(class_124.field_1080));
            Axon.chatMessage(msg3);
            return 0;
        }

        try {
            LLMService.setKey(key);
            if (provider != null) {
                LLMService.setProvider(provider);
                class_5250 msg = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470("Provider set to " + LLMService.getProviderDisplayName(provider) + ".").method_27692(class_124.field_1080));
                Axon.chatMessage(msg);
            } else {
                String detected = LLMService.detectProvider(key);
                if (detected != null) {
                    class_5250 msg = Utils.prefixText("Axon AI")
                            .method_10852(class_2561.method_43470("Auto-detected provider from key: " + LLMService.getProviderDisplayName(detected)).method_27692(class_124.field_1080));
                    Axon.chatMessage(msg);
                } else {
                    class_5250 msg = Utils.prefixText("Axon AI")
                            .method_10852(class_2561.method_43470("Could not detect provider from key; using " + LLMService.getProviderDisplayName(LLMService.getProvider()) + ". Specify it with /a-key <key> <provider_name>.").method_27692(class_124.field_1054));
                    Axon.chatMessage(msg);
                }
            }
        } catch (Exception e) {
            Axon.LOGGER.error("Failed to set LLM key/provider", e);
            class_5250 msg = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Failed to set key: " + e.getMessage()).method_27692(class_124.field_1061));
            Axon.chatMessage(msg);
            return 0;
        }

        String activeProvider = LLMService.getProvider();
        class_5250 msg = Utils.prefixText("Axon AI")
                .method_10852(class_2561.method_43470("Key set successfully").method_27692(class_124.field_1077))
                .method_10852(class_2561.method_43470(" (provider: " + LLMService.getProviderDisplayName(activeProvider) + ")").method_27692(class_124.field_1080));
        Axon.chatMessage(msg);
        String autoModel = LLMService.getDefaultModelFor(activeProvider);
        if (autoModel != null) {
            class_5250 msg2 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Auto-selected model: " + autoModel).method_27692(class_124.field_1075))
                    .method_10852(class_2561.method_43470(" (change with /a-model <model name>)").method_27692(class_124.field_1080));
            Axon.chatMessage(msg2);
            class_5250 msg3 = Utils.prefixText("Axon AI")
                    .method_10852(class_2561.method_43470("Suggested models for " + activeProvider + ":").method_27692(class_124.field_1080));
            Axon.chatMessage(msg3);
            for (String suggestion : LLMService.getSuggestedModels(activeProvider)) {
                class_5250 msg4 = Utils.prefixText("Axon AI")
                        .method_10852(class_2561.method_43470(" - " + suggestion).method_27692(class_124.field_1062));
                Axon.chatMessage(msg4);
            }
        }
        class_5250 msg5 = Utils.prefixText("Axon AI")
                .method_10852(class_2561.method_43470("Now set the model using /a-model <model name>").method_27692(class_124.field_1075));
        Axon.chatMessage(msg5);
        class_5250 msg6 = Utils.prefixText("Axon AI")
                .method_10852(class_2561.method_43470("Providers available: " + LLMService.getProvidersDescription()).method_27692(class_124.field_1080));
        Axon.chatMessage(msg6);
        return 1;
    }
}
